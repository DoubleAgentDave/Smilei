Licence
-------

:program:`Smilei` is protected by a **licence CeCILL**, the french equivalent to
the open-source Gnu GPL license.

Extract:
  
  *This software is governed by the CeCILL-B license under French law and
  abiding by the rules of distribution of free software.  You can  use, 
  modify and/ or redistribute the software under the terms of the CeCILL-B
  license as circulated by CEA, CNRS and INRIA at the following URL*
  `http://www.cecill.info <http://www.cecill.info>`_.
  
You can also find more information about the licence in the downloadable tarball of the
:ref:`latest version of the code<latestVersion>`