.. title:: Understand

Understand
==========

.. toctree::

   units
   algorithms
   parallelization
   vectorization
   collisions
   ionization
   radiation_loss
   multiphoton_Breit_Wheeler
   particle_merging
   particle_injector
   laser_envelope
   relativistic_fields_initialization
